# UCEF MySQL Wrapper

On the path of realizing the dream of UCEF, allowing for integration with a database became of paramount importance. The UCEF MySQL Wrapper allows for any federation's data to be stored within a MySQL database.

## Getting Started
More details soon to come!
```
Tip: You'll need to install the UCEF virtual machine.
```

## Author
James Arnold

## Acknowledgments

* Hat tip to Dr. Thomas Roth.
